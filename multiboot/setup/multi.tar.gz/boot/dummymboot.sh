#!/bin/sh

#dummy only






echo "dummyboot.sh $0 WHOOOOOOOOOOOOOO " > /dev/kmsg


exit 0




