#!/bin/sh
#REVERT
#2>&1 >/dev/kmsg

#VERSION30.1 FRESHOS
############################# changelog
#.restoreprefix no + partinit = [ok]





ZW="/boot/rpi-multi-init.sh"
xY=">>>--------->>>"


DISK="/dev/mmcblk0"; DISKf="/dev/mmcblk0p" #migratetothis@alternatedevices ### @?> case-cmdline fixup non-p #DISKfNOTE: '0p'='sd'!!!





usage() {
cat <<EOF

	$ZW

		This script is not to be run by hand... !


#usage ramopt=partinit||partextent <<< ucidef param1 
#usage ramopt=scriptname.sh(no.sh?)
#usage ramopt=scriptname.sh(no.sh?)
EOF
}






echz() {
    echo "$ZW: ${*}" > /dev/kmsg
    echo "$ZW: ${*}" >> /tmp/$ZW.log
    sleep 1
}



#fails???
cleanup() {
	#$1@ENDRESULT? (aka SHORTMSGREASONhandle)
	echo "$ZW: #################################### CANCELOPERTATION>CLEANUP>SENDSIGs" >> /dev/kmsg && sleep 2

	echo "$ZW: ${*}" >> /dev/kmsg; echo "$ZW: ${*}" >> /tmp/$ZW.log; sleep 3

	echo "$ZW: cp /tmp/$ZW.log /tmp/bootscript.failed" >> /dev/kmsg && sleep 3
	cp /tmp/$ZW.log /tmp/bootscript.failed #ff-dual@.success<-beganhere>10-x
}
fails() { cleanup ${*}; }






fsckadisk() { #rename this2 to test both?

#1 fstype
#2 /dev/diskNUM

echz "fsck@$2 [$1:fsck]"

    case "$1" in
        fat)

            #fsck.fat -y /dev/mmcblk0p1 #&& echz "retval:$?" #fsck.fat -n /dev/mmcblk0p1 &>/dev/null && echo $? > /dev/kmsg
            echz "$(fsck.fat -y $2)"
            echz "retval:$?"

        ;;
        ext4)


            #echz "fsck@$2 [init-report]"
            fsck.ext4 -n $2 &>/dev/null; retval=$?
            #echz "retval: $?"
            if [ "$retval" -ne 0 ]; then
                echz "fsck@$2 [fsck-repair]"
                fsck.ext4 -y $2 &>/dev/null
                echz "retval: $?"
            else
                echz "fsck@$2 [fsck-clean]"
            fi


        ;;
        *)
            echz "$FN> unknown fs: $1"
        ;;
    esac

}






cmdlinegetprop() {

    FN="cmdlinegetprop"

    local cmdlinegetprop="${1}" #rootfs|ramopt|...

	if read cmdline < /proc/cmdline; then
        #######################################################################
	case "$cmdlinegetprop" in
		
		rootfs) case "$cmdline" in
			*root=*) cmdlineprop="${cmdline##*root=}"; cmdlineprop="${cmdlineprop%% *}"; ;;
		esac; ;;

		ramopt) case "$cmdline" in
                    	*ramopt=*) cmdlineprop="${cmdline##*ramopt=}"; cmdlineprop="${cmdlineprop%% *}"; ;;
                esac; ;;
	
	esac #endcase1cmdlinegetprop
        #######################################################################
	if [ ! -z "${cmdlineprop}" ]; then echo "${cmdlineprop}"; return 0; fi
	
	else
		echo "cmdline is not readable" >> /tmp/ISSUELOG #echU "cmdline is not readable"
        	fails "$FN> commandline-notreadable"
    	fi
	
	return 1
} #cmdlineprop-ZCANTECHO: #echo "cmdline@$cmdlinegetprop empty" ######echU "cmdline@$cmdlinegetprop empty"
#echo "$(cat /boot/cmdline.txt) os_prefix=$OSdir ramopt=partinit" > "$OSbase/$OSdir/cmdline.txt"







#echz "/proc/cmdline [peek]"; echz "$(cat /proc/cmdline)"
#echz "/proc/cmdline tail -c10 [peek]"; echz "$(tail -c10 /proc/cmdline)"









echz "init"; sleep 2
echz "init WHOAMI: $0"; sleep 2



fSAVEm="log.partinit"
fdiskSAVE="${fSAVEn}.fdisk.save"




if [ ! -b "$DISK" ]; then echz "$xW HOLYSHIT no DISK:$DISK"; sleep 2; NODISK=1; fi



#if [ -z "$NODISK" ]; then
echz "$xY info: FDISK layout: $DISK"
fdisk -l $DISK | grep type 2>&1 >/dev/kmsg #grep -q 'dos'


echz "$xY info: FDISK layout: $DISK dump original >/tmp/${fdiskSAVE}.org"


#fi; #4linesmessy: echz "$xY info: GDISK layout: $DISK"; gdisk -l $DISK | grep -A4 'scan' 2>&1 >/dev/kmsg; sleep 2


########################################## for now well SKIPassume if blkp then has fs... also fsck ext4 all early for fun for now
#if [ -b /dev/mmcblk0p2 ]; then fsckadisk "ext4" "/dev/mmcblk0p2"; fi
#if [ -b /dev/mmcblk0p3 ]; then fsckadisk "ext4" "/dev/mmcblk0p3"; fi
#if [ -b /dev/mmcblk0p4 ]; then fsckadisk "ext4" "/dev/mmcblk0p4"; fi






NOPETHISSHOULDHAVEBEENHANDLEDBYRAMFS() { #!!! need to copy $0 > ramfs /tmp !!! @umount??????????? WELLWECANDUMPAPARTBACKUPEARLY?!


########################################### we always need to mount boot... do a mount check first
if mount | grep -q '^/dev/mmcblk0p1'; then
    echz "/boot ismounted-early !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!"
    umount /boot || echz "unable to umount /boot"
fi

echz "setting up /boot@/dev/mmcblk0p1 [init]"
if [ -b /dev/mmcblk0p1 ]; then
    fsckadisk "fat" "/dev/mmcblk0p1"
fi

echz "setting up /boot@/dev/mmcblk0p1 [(re)mount]"
mkdir -p /boot
mount /dev/mmcblk0p1 /boot &>/dev/null

if [ ! -f /boot/config.txt ]; then
    echz "/boot@/dev/mmcblk0p1 [issues-no-config.txt]"; issues="${issues} bootmountproblem"
else
    echz "mount /boot [ok]"
fi
echz "setting up /boot@/dev/mmcblk0p1 [done]"
}







echz "MARKER 1.9 CHECK FOR: fdisk sfdisk blkid [lsof"











if [ -z "$os_prefix" ]; then echz "dbg-early-os_prefix: Z > os0 [detectfunctmpdisabled]"; fi
os_prefix=${os_prefix:-os0}
### WORKAROUND IF THIS SCRIPT IS CALLED THEN os_prefix=os0


echz "############################################################# JUICYINFO"
echz "$ZW: /tmp/$ZW.log @cleanup >>> /tmp/bootscript.failed"
echz "env os_prefix: $(echo $os_prefix)"
echz "############################################################# JUICYINFOEND"




########################3 we should do another checkprereq here @ ramfs.func - ish
#lsof fdisk sfdisk blkid



echz "MARKER 1.9"










DONTTHINKINEEDTHISHEREORMAYBEPASSVIAtmpDOTsomethingINI() { ############################ WASONWASONWASON


echz "env os_prefix: $(echo $os_prefix)"

#cat /boot/config.txt | grep '^os_prefix='
ospfxnum=$(cat /boot/config.txt | grep '^os_prefix=' | wc -l)
ospfxlast=$(cat /boot/config.txt | grep '^os_prefix=' | tail -n1)
echz "config.txt os_prefix: $ospfxlast [current]"; sleep 2


if [ -f /boot/.prefixrestore ]; then
    echz "/boot/.prefixrestore [load]"
    echz "cat $(cat /boot/.prefixrestore)"
    . /boot/.prefixrestore
    
    echz "/boot/config.txt [comment out current $ospfxlast]"
    sed -i "s!^$ospfxlast!#$ospfxlast!g" /boot/config.txt
    echz "/boot/config.txt [commentout os_prefix check playback"
    echz "$(cat /boot/config.txt | grep 'os_prefix')"
        
    echz "/boot/config.txt [reset os_prefix:$os_prefix]"
    sed -i "s!^#os_prefix=$os_prefix!os_prefix=$os_prefix!g" /boot/config.txt

    echz "/boot/config.txt [reset os_prefix:$os_prefix] check playback"
    echz "$(cat /boot/config.txt | grep '^os_prefix')"

else
    
    #echz "/boot/.prefixrestore [nope]"
    #echz "probably just disable self line here $ospfxlast [nope]"
    


	#if os_prefix = os0 !always

	if [ -f /boot/.initialize ]; then

    		echz "/boot/.prefixrestore [nope] > .initialize [ok]"
    		echz "dbg: ospfxlast: $ospfxlast [nope]"

    		echz "NOTE: reboot seds this elsewhere on initialize sed -i \"s!^$ospfxlast!#$ospfxlast!g\" /boot/config.txt"
		#sed -i "s!^$ospfxlast!#$ospfxlast!g" /boot/config.txt


		#HINT [   35.961829] /boot/rpi-multi-init.sh: PARTSETUP > restoreos=os99 aka NOTHING

	else

		echz "/boot/.prefixrestore [nope:non-initialze:oops>disableall?]"
		echz "probably just disable self line here $ospfxlast [nope]"
		echz "sed -i \"s!^$ospfxlast!#$ospfxlast!g\" /boot/config.txt"
		#sed -i "s!^$ospfxlast!#$ospfxlast!g" /boot/config.txt
		echz "############ YOUMUSTDOTHISMANUALLYNOW"


	fi

fi

} #wasinitally FLOATING now dont detect osprefix from subscript TEST


#NOTE: likely will spawn seperate scripts from uci-def...???
#echo "$(cat /boot/cmdline.txt) os_prefix=$OSdir ramopt=partinit" > "$OSbase/$OSdir/cmdline.txt"






sfdiskappendpartsstaticfile() {
#1 original(matched)dump
#2 ?
#cat $1 #if1isafilename cat? #notbad tabswrong while read LINE; do echo $LINE; done #cat WORKS!!!
cat
cat <<-'EOF'
/dev/mmcblk0p3 : start=     2768896, size=     2097152, type=83
/dev/mmcblk0p4 : start=     4866048, size=     2097152, type=83
EOF
}







dskismounted() {

	local dskMPT="${1}"
	local dskDEV="${2}"

	#echz "lsof | grep boot >> /tmp/lsof11"; lsof | grep boot >> /tmp/lsof11
	#echz "DBG: dskismounted ${*}"
	if mount | tr -s '\t' ' ' | grep -q "$dskDEV"; then
		#echz "DBG: dskismounted ${*} [YES:ret0]"
		return 0
	else
		#echz "DBG: dskismounted ${*} [NO:ret1]"
		return 1
	fi

}

#root@OpenWrt:/# cat /tmp/lsof10  | grep boot
#sh        423 root   10r      REG                0,2    33363 2057 /etc/uci-defaults/10-runbootscript




umountadiskplease() {


	#1 disk mountpoint aka /boot
	local dskMPT="${1}"
	local dskDEV="${2}" #useful if mounted else where
	local waitCNT="${3:-7}" #useful if mounted else where


	if ! dskismounted "$dskMPT" "$dskDEV"; then
		echz "### BOOT WAS NOT MOUNTED $(mount | grep "$dskDEV")"
		sleep 2
		return 0
	else
		echz "### $dskMPT ISMOUNTED $(mount | grep "$dskDEV")"
		sleep 2
        fi
    

	#echz "Waiting for umount boot $count: $dskMPT (sleep 1)" #printf 'Waiting for umount boot: %s\r' "$1"
    	#sleep 1


	count=0
	#while true; do
	while dskismounted "$dskMPT" "$dskDEV"; do
		
		echz "Waiting for umount ${dskMPT} $count:$waitCNT (sleep 1)" #printf 'Waiting for umount boot: %s\r' "$1"
    		sleep 1

		echz "COMMAND> umount ${dskMPT}"
		umount /boot


    		count=$((count+1))
    		if [[ ${count} -eq ${waitCNT} ]]; then
			echz "Waiting for umount $dskMTP $count:$waitCNT (timeout->breakloop->ret1)"
			break
    		fi
	done

	if dskismounted "$dskMPT" "$dskDEV"; then
		echz "Postloop umount: $dskMPT count: $count [FAIL]"
		return 1
	else
		echz "Postloop umount: $dskMPT count: $count [SUCCESS]"
	fi

	return 0
}






[ -n "$DEBUG" ] && echz "DBG-MARKER2.3"






#EARLY pre-umountORmoveback ifnofilePREUMOUNT sfdisk -d > /sfd-mmcblk0-orig

case "$(cat /proc/cmdline)" in




	##################################### CASESTART
    *"multisetup"*|*"ramopt=partinit"*)
        
        echz "###########################################"
        echz "   ###########  MULTISETUP #############"
        echz "###########################################"
	#we are trying to setup disk parts... force prefixrestore aka all config.txt os_prefix OFF!!!
    	echz "PARTSETUP > restoreos=os99 aka NOTHING partinit > sed all os_prefix off"
	sed -i "s!^os_prefix=!#os_prefix=!g" /boot/config.txt
	
	echz "sleep 3"
	sleep 3
	#probably sed os0 cmdline too...(here?and) on success / fail


	#CHECKFOREXISTING /boot/.initialize echo<duringthisscriptforfailleave ... touch /boot/.multi.setup

	if [ -f /boot/.initialize ]; then
		echz "initialize present"
	else
		echz "initialize notpresent [dbg-keepgoinganyway]"
	fi

        mmcpartcount=$(blkid  | grep '^/dev/mmcblk0p' | wc -l)
        
        if [ "$mmcpartcount" -ne 2 ]; then
		echz "mmcpartcount: $mmcpartcount [not-2]"
		
		echz "testing-failfriendly-continue-altsetups-n-log"
		sfdisk -d /dev/mmcblk0 > /tmp/multisetup.parts.vanillanot
		PARTSCREATED=1

	    #echo "WIP cleanup exit 1"; exit 1
            #cleanup /boot/.initialize /boot/os0/cmdline.txtSED...
        else
            echz "mmcpartcount: $mmcpartcount [2-good]"
            echo "mmcpartcount: $mmcpartcount [2-good]" >> /boot/.initialize
	    sync
	    PARTVANILLA=1
	fi

        


	echz "sfdisk dumpcurrent table > /tmp/table"
	sfdisk -d /dev/mmcblk0 > /tmp/table

	#echz "edit and sfdisk /dev/mmcblk0 < /tmp/table"



        #echz "umount /boot 1"
        #umount /boot || echz "1 hmmm... possible umount boot issue pwd:$PWD"
	#echz "umount /boot 2"
        #umount /boot || echz "2 hmmm... possible umount boot issue pwd:$PWD"
	#echz "umount /boot 3"
        #umount /boot || echz "3 hmmm... possible umount boot issue pwd:$PWD"


        #echz "umount /boot 1"
        #umount /boot || umountadiskplease "/boot" "/dev/mmcblk0p1" "7"



	umountadiskplease "/boot" "/dev/mmcblk0p1" "7" || ISSUES="${ISSUES} umountadiskpleasefailed"

	

	echz "dump-a-lsof ?> /tmp/lsof10"
	lsof > /tmp/lsof10



	echz "paranoid final still mount@boot check"
	if mount | grep '^/dev/mmcblk0p1' | grep q '/boot'; then
		echz "umount boot: $(mount | grep boot) FAILED"
		echz "umount boot: $(lsof | grep boot) FAILED"
		ISSUES="${ISSUES} umountboot-pre-sfdiskaddparts-failed"
	else
		echz "umount boot: $(mount | grep boot) OK"
	fi




	#echo "REALOSTEST exit"; exit 0





	if [ -z "$PARTVANILLA" ]; then
		ISSUES="${ISSUES} partnovanilla"
	fi


	if [ ! -z "${ISSUES}" ]; then
		echz "ISSUES: ${ISSUES} [bailing-umount-boot]"
		exit 11
	fi



	[ -n "$DEBUG" ] && echz "DBG-MARKER2.5"










#@TOP fSAVEm="log.partinit"
#@TOP fdiskSAVE="${fSAVEn}.fdisk.save"
#ORG sfRESTOREfMB=/tmp/sfdiskmultiboot




DISK=/dev/mmcblk0
sfRESTOREfMB=/tmp/${fSAVEn}.sfdisk.newparts
sfRESTOREfORG=/tmp/${fSAVEn}.sfdisk.original


echz "Saving original layout: sfdisk -d ${DISK} > $sfRESTOREfORG"
sfdisk -d ${DISK} > $sfRESTOREfORG





if [ "$(sfdisk -d /dev/mmcblk0 | grep '^/dev/' | wc -l)" -eq 2 ]; then

	if sfdisk -d /dev/mmcblk0 | grep '^/dev/' | tail -n1 | grep -q '802816'; then

		echz "fdisk create mmcblk0p3 mmcblk0p4"

		echz "$DISK last part OK: $(sfdisk -d /dev/mmcblk0 | grep '^/dev/' | tail -n1)"

		echz "Writing two more part entries"


		#appendparts-renamed
		#echz "sfdisk -d $DISK | appendparts > /tmp/SDDISKnewDBG"; sfdisk -d $DISK | appendparts > /tmp/sfdiskmultiboot


		echz "sfdisk -d $DISK | appendparts > $sfRESTOREfMB"
		sfdisk -d $DISK | sfdiskappendpartsstaticfile > $sfRESTOREfMB


		#@@@ validate the file... even test restore cmd NOACTION
		sfRESTOREfMBcnt=$(cat $sfRESTOREfMB | grep '^/' | wc -l)
		echz "RESTFILEVALIDATE: $sfRESTOREfMB [$sfRESTOREfMBcnt]"
		if [ "$sfRESTOREfMBcnt" -ne 4 ]; then
			ISSUES="${ISSUES} restfile-ne-4"
		fi



		if [ ! -z "${ISSUES}" ]; then
			echz "ISSUES: $ISSUES"
			echz "bailing pre sfdisk [SKUPPINGexitHERE>stillcreaterestoffilesDEBUG]"
			#exit 11
		fi




		echz "################################################"
		echz "sfdisk $DISK < $sfRESTOREfMB"
		sfdisk $DISK < $sfRESTOREfMB
		SFWRITEret=$?
		echz "sfdisk write: $SFWRITEret"; sleep 2


		if [ "$SDWRITEret" -ne 0 ]; then
			echz "sfdisk $DISK < /tmp/sfdiskmultiboot FAILED"
			PARTSCREATED=
		else
			PARTSCREATED=1
		fi


		#partprobe? reboot without toggle?&&?modcmdline.txt@fscreate NEEDtomountbootandsavelogsbackupsfirst? ':('
	
	else
		echz "$DISK last part not 802816: $(sfdisk -d /dev/mmcblk0 | grep '^/dev/' | tail -n1)"
		ISSUES="${ISSUES} invalLASTPARTSZ"
	fi

else
	echz "$DISK has invalid partnum: $(sfdisk -d /dev/mmcblk0 | grep '^/dev/' | wc -l)"
	ISSUES="${ISSUES} invalPARTNUM"
fi










if [ -z "$PARTSCREATED" ]; then
	echz "partions-fs-setup skip [ok-mmc:$mmcpartcount] PARTSCREATED z"
else

	: #runpartionfunctions
	echz "partions-fs-setup [ok-mmc:$mmcpartcount]"


#if parts create echo >> /boot/.initialize || parts found?




echz "mkfs.ext4 -L os1 /dev/mmcblk0p3 [test]"
if ! blkid | grep '^/dev/mmcblk0p3' | grep ' UUID='; then
    #echz "dbg-manualoff: mkfs.ext4 -L os1 /dev/mmcblk0p3"
    echz "mkfs.ext4 -L os1 /dev/mmcblk0p3"
    mkfs.ext4 -L os1 /dev/mmcblk0p3
else
    echz "fs: os1@/dev/mmcblk0p3 [already]"
    echz "$(blkid | grep '^/dev/mmcblk0p3')"
fi


if ! blkid | grep '^/dev/mmcblk0p4' | grep ' UUID='; then
    #echz "dbg-manualogg: mkfs.ext4 -L os2 /dev/mmcblk0p4"
    echz "mkfs.ext4 -L os2 /dev/mmcblk0p4"
    mkfs.ext4 -L os2 /dev/mmcblk0p4
else
    echz "fs: os2@/dev/mmcblk0p4 [already]"
    echz "$(blkid | grep '^/dev/mmcblk0p4')"
fi




echz "mkfs.ext4 -L os3 /dev/sdaX [not-implemented-please-do-manually"
COMPLEXsdXCHECKSSKIP() { #ignore sdX here

############################################## initial-verbose-debug-status
if blkid | grep -q '^/dev/sd'; then
	
	sdpartcount=$(blkid | grep -q '^/dev/sd' | wc -l) #(all)
	sddiskcount=$(blkid | grep '^/dev/sd' | cut -d':' -f1 | cut -c 1-8 | sort | uniq)

	if [ "$sddiskcount" -gt 1 ]; then
		echz "multiple sd disks detected"
		blkid | grep '^/dev/sd' | cut -d':' -f1 | cut -c 1-8 | sort | uniq > /dev/kmsg
	fi

	#loop even on 1 anyway
	blkid | grep '^/dev/sd' | cut -d':' -f1 | cut -c 1-8 | sort | uniq > /tmp/sddisks
	for disk in $(cat /tmp/sddisks); do

		diskpartcnt=$(blkid | grep -q '^/dev/sd' | wc -l)
		
		echz "sd: $disk partcount:$diskpartcount"

		blkid | grep "^$disk" > /dev/kmsg
		blkid | grep "^$disk"

		if ! blkid | grep "^$disk" | grep ' UUID='; then
			echz "sd partitions all have no filesystems"
		fi

	done

fi; sleep 2 #ENDSD-VERBOSE-CHECK-and-REPORT>validparts?>validfsYUP@... synoearlyinstallerscriptsORbootsetup.sh???
















} ########## ENDsdXCHECKSL




















mkdir -p /tmp/rootorg /tmp/os1 /tmp/os2

mount /dev/mmcblk0p2 /tmp/rootorg



mount /dev/mmcblk0p3 /tmp/os1
echz "cp -arf /tmp/rootorg/. /tmp/os1/"
cp -arf /tmp/rootorg/. /tmp/os1/
sync


mount /dev/mmcblk0p4 /tmp/os2
echz "cp -arf /tmp/rootorg/. /tmp/os2/"
cp -arf /tmp/rootorg/. /tmp/os2/
sync



umount /tmp/os2
umount /tmp/os1
umount /tmp/rootfsorg











############################################################# NEED PROPER PARTITION FROM multiboot.ini

notnowplsseeaboveredetectingviamultibootiniandfailfriendlyandordetectformattedemptypartition() {
if ! blkid | grep '^/dev/sda4' | grep ' UUID='; then
    echz "mkfs.ext4 -L os2 /dev/sda4 [test]"
    mkfs.ext4 -L os2 /dev/sda4
else
    echz "fs: os2@/dev/mmcblk0p4 [already]"
    echz "$(blkid | grep '^/dev/mmcblk0p4')"
fi
}





#if FORMATOK rm||mv /initialize prob sed os0/cmdline.txt





fi #ENDPARTSNOTCREATEDelse










#################@@@ cleanup etc.
######@@@???cp LOGFILE > /tmp/bootscript.failed? @main cp /boot?

MMCDISKvalidFS=$(blkid | grep "^$DISK" | grep ' UUID=' | wc -l)
if [ "$MMCDISKvalidFS" -eq 4 ]; then
	echz "SUCCESS"
	#echz "Success found 4 mmc validparts NOTE:USBNOTFACTORED (early individual check)"
	

	echz "mount /dev/mmcblk0p1 /boot"
	mount /dev/mmcblk0p1 /boot
	sleep 2

	echz "rm /boot/.initialize"
	rm /boot/.initialize
	sleep 1


	echz "sed /boot/os0/cmdline.txt"
	sed -i 's! ramopt=partinit!!g' /boot/os0/cmdline.txt


	echz "TODO select OS1 as the next OS (and touch something to say its the first / setup next etc.)"
	sleep 3


	echz "touch /tmp/bootscript.success"
	touch /tmp/bootscript.success

else
	echz "Failed found $MMCDISKvalidFS mmcparts NOTE:USBNOTFACTORED (early individual check)"
	echz "touch /tmp/bootscript.failed"
	touch /tmp/bootscript.failed
fi



		echz "sync..."; sync



		#echz "REBOOTOFF see /tmp/SF ... reboot > or back in script1 based on retval"

		#@@@ was leaving to main... checks .failed .success... 
		#possibly umount boot etc...
		#umount /boot

		echz "reboot > or back in script1 based on retval or .failed .success if ramopt=partinit"
		reboot




	##################################### CASEEND
    ;;



    *)
        echz "###########################################"
        echz "    ########  UNKNOWNREASON  #########"
        echz "###########################################"
	#!!! check boot is remounted!!!
	#???REVERTFAIL=1 #@10-ramfsucidef... useseperatenamehere && pass params back? via ff? if needed???
   
   ;;
esac








echz "remounting boot for cleanup"
if ! mount | grep '^/dev/mmcblk0p1' | grep q '/boot'; then
	mount /dev/mmcblk0p1 /boot || BOOTmNO=1
	if [ ! -z "$BOOTmNO" ]; then
		echz "prob?: mount grep boot: $(mount | grep boot)"
	else
		echz "ok?: mount grep boot: $(mount | grep boot)"

		echz "COPY /tmp/SDDISK.* /boot/..."
	fi

	sleep 3
fi










#echz "#########"; echz "ALLDONE"; echz "#########"





echz "######### CHECK ending cmdline sedded back"
echz "$(cat /boot/os0/cmdline.txt)"
echz "$(cat /boot/os0/cmdline.txt | tail -c15)"
sleep 2






#if ALLGOOD the rm /boot/.initialize echo<duringthisscriptforfailleave ... touch /boot/.multi.setup






echz "######################################################################"
echz "end >>> reboot manually until all auto seds/reverts/etc/ are sorted"
echz "######################################################################"
sleep 2



############### we might check this... && need to && we are not uci-defaults so EXIT 0 !!! (later test main alt logic first)
exit 1



#opkg install fixparts


#NOTE: re mount weirdos -i = nohelper


#####################sfdisk /dev/sda < file.txt #RESTORE
####################DISK=/dev/mmcblk0; sfdisk -d $DISK | appendparts #JUSTDUMPTEST
#DISK=/dev/mmcblk0; sfdisk -d $DISK | appendparts > sfdisk $DISK
#sfdisk -d > /sfd-mmcblk0-orig
#cat mmcblk0-setup-sdisk.dump | grep '^/dev/' | wc -l #4
#sfdisk -d /dev/mmcblk0 | grep '^/dev/' | wc -l #4
#if [ "$(sfdisk -d /dev/mmcblk0 | grep '^/dev/' | wc -l)" -eq 2 ]; then
#/dev/mmcblk0p1 : start=        8192, size=      786432, type=c, bootable
#/dev/mmcblk0p2 : start=      802816, size=     1966080, type=83

















SGDISKpartMOVE() {

	:
#Using sgdisk you can create a binary backup consisting of the protective MBR, the main GPT header, the backup GPT header, and one copy of the partition table. The example below will save the partition table of /dev/sda to a file sgdisk-sda.bin:

# sgdisk -b=sgdisk-sda.bin /dev/sda



# sgdisk -l=sgdisk-sda.bin /dev/sda #later restore the backup by running:



#If you want to clone your current device's partition layout (/dev/sda in this case) to another drive (/dev/sdc) run:

# sgdisk -R=/dev/sdc /dev/sda



# sgdisk -G /dev/sdc #both drives will be in the same computer randomize the disk and partition GUIDs:



}


















sfdiskmethodmremadefull() {

################################ may need to remove sector size may also need last two lines only
sfdisk /dev/mmcblk0 << __EOF__
label: dos
label-id: 0x5452574f
device: /dev/mmcblk0
unit: sectors
sector-size: 512

/dev/mmcblk0p1 : start=        8192, size=      786432, type=c, bootable
/dev/mmcblk0p2 : start=      802816, size=     1966080, type=83
/dev/mmcblk0p3 : start=     2768896, size=     2097152, type=83
/dev/mmcblk0p4 : start=     4866048, size=     2097152, type=83
__EOF__

}




gdiskheredocs1dangerconvertstogpt() {
################################### WARNING converts to gpt but got sfdisk start etc.
#######gdisk
gdisk /dev/mmcblk0 << __EOF__
n
3

+1G
8300
w
Y
__EOF__

#######gdisk
gdisk /dev/mmcblk0 << __EOF__
n
4

+1G
8300
w
Y
__EOF__


}
#or just g (man gdisk deb)
#However, according to the man page, gdisk, which is used to convert MBR -> GPT, also has an option in the "recovery & transformation" menu (press r to get that) to convert GPT -> MBR; the g key will:
#or x > z



























wedontcallourself() {

bootscript="/boot/$(ls -1 /boot/ | grep "$ZBSCRIPT" | head -n1)"
echz "###############################################################"
echz "bootscript: $bootscript [nameprint@endsin${ZBSCRIPT}]"
echz "###############################################################"
sleep 1


if [ -z "$bootscript" ]; then
    echz "bootscript not found: $bootscript $ZBSCRIPT"
elif [ -f "$bootscript" ]; then #if [ ! -x "$bootscript" ]; then
    echz "bootscript: $bootscript [execute]"
    sleep 2
    sh $bootscript
    echz "bootscript: $bootscript [done]"
    sleep 2

else    
    echz "bootscript: -f NOPE $bootscript"
fi

}





    ####################################################################
    #echz "/boot/config.txt [reset os_prefix:$os_prefix]"
    #sed -i "s!^os_prefix=.*!os_prefix=$os_prefix!g" /boot/config.txt
    ####################################################################
    #echz "/boot/config.txt [reset os_prefix:$os_prefix] check playback"
    #echz "$(cat /boot/config.txt | grep '^os_prefix')"
    ####################################################################
    

#echz "/boot/config.txt [reset os_prefix:$os_prefix]"
#sed -i "s!^os_prefix=.*!os_prefix=$os_prefix!g" /boot/config.txt
#echz "/boot/config.txt [reset os_prefix:$os_prefix] check playback"
#echz "$(cat /boot/config.txt | grep '^os_prefix')"


#bootscript="/boot/$(ls -1 /boot/ | head -n1)"




#root@OpenWrt:/# fsck.fat /dev/mmcblk0p1 
#CP437: No error information
#fsck.fat 4.1 (2017-01-24)
#0x25: Dirty bit is set. Fs was not properly unmounted and some data may be corrupt.
#1) Remove dirty bit
#2) No action



















#root@OpenWrt:/# sfdisk -d /dev/mmcblk0 > /tmp/tableGPTnew
#root@OpenWrt:/# cat /tmp/tableGPTnew
#label: gpt
#label-id: 28BE9558-8D3E-4095-9BD6-675E63509ADA
#device: /dev/mmcblk0
#unit: sectors
#first-lba: 34
#last-lba: 62521310
#sector-size: 512
#
#/dev/mmcblk0p1 : start=        8192, size=      786432, type=EBD0A0A2-B9E5-4433-87C0-68B6B72699C7, uuid=051AEDDB-BDE2-43B6-B054-9FBF4C"
#/dev/mmcblk0p2 : start=      802816, size=     1966080, type=0FC63DAF-8483-4772-8E79-3D69D8477DE4, uuid=D801B487-DFB9-474D-8DA1-065882"
#/dev/mmcblk0p3 : start=     2768896, size=     2097152, type=0FC63DAF-8483-4772-8E79-3D69D8477DE4, uuid=36960247-C6AB-407B-8BB0-C511B2"
#/dev/mmcblk0p4 : start=     4866048, size=     2097152, type=0FC63DAF-8483-4772-8E79-3D69D8477DE4, uuid=04535BE2-44ED-457E-9D20-F976B3"



##########################root@OpenWrt:/# cat /tmp/table
#label: dos
#label-id: 0x5452574f
#device: /dev/mmcblk0
#unit: sectors
#sector-size: 512
#
#/dev/mmcblk0p1 : start=        8192, size=      786432, type=c, bootable
#/dev/mmcblk0p2 : start=      802816, size=     1966080, type=83




#Device     Boot   Start     End Sectors  Size Id Type
#/dev/sdg1  *       8192  794623  786432  384M  c W95 FAT32 (LBA)
#/dev/sdg2        802816 2768895 1966080  960M 83 Linux
#/dev/sdg3       2768896 4866047 2097152    1G 83 Linux
#/dev/sdg4       4866048 6963199 2097152    1G 83 Linux






################# USED GDISK TO CREATE (butturnedintogpt) needed backup img... but cp sfdisk of new partinfo

################# debian did not like line 5 @ 512 had to remove to restore... not sure about openwrt












fdiskpartcreatefailsthinksstartsectoris2048() {

#n
#p
#4
#
#+1G
#t
#83
#p
#w


#n
#p

fdisk /dev/mmcblk0 << __EOF__
n
p
3

+1G
t
83

w

__EOF__


fdisk /dev/mmcblk0 << __EOF__
n
p
4

+1G
t
83

w

__EOF__





}















#########################################################!/bin/sh
#ZED="/etc/uci-defaults/10-runbootscript"
#ZBSCRIPT="rpi-multi-init.sh" #ZBSCRIPT="rpimod.sh"







#sfdisk -d > /sfd-mmcblk0-orig
#cat mmcblk0-setup-sdisk.dump | grep '^/dev/' | wc -l #4
#sfdisk -d /dev/mmcblk0 | grep '^/dev/' | wc -l #4
#/dev/mmcblk0p1 : start=        8192, size=      786432, type=c, bootable
#/dev/mmcblk0p2 : start=      802816, size=     1966080, type=83



#IF
#/dev/mmcblk0p1 : start=        8192, size=      786432, type=c, bootable
#/dev/mmcblk0p2 : start=      802816, size=     1966080, type=83
#/dev/mmcblk0p3 : start=     2768896, size=     2097152, type=83
#/dev/mmcblk0p4 : start=     4866048, size=     2097152, type=83




# sgdisk -b=sgdisk-sda.bin /dev/sda

#####################sgdisk -m /dev/sda #CONVERTgpt to mbr 4partsonly?













#2>&1 >/dev/kmsg


#if [ -z "$NODISK" ]; then
echz "$xY info: FDISK layout: $DISK"
fdisk -l $DISK | grep type 2>&1 >/dev/kmsg

echz "$xY info: GDISK layout: $DISK"
gdisk -l $DISK | grep -A4 'scan' 2>&1 >/dev/kmsg
#fi
sleep 2















mkdir -p /tmp/1 /tmp/2

mount "$part1" /tmp/1
mount "$part2" /tmp/2

sed /tmp/1/cmdline.txt -i -e "s|root=[^ ]*|root=${part2}|"
sed /tmp/2/etc/fstab -i -e "s|^[^#].* / |${part2}  / |"
sed /tmp/2/etc/fstab -i -e "s|^[^#].* /boot |${part1}  /boot |"


  if ! grep -q resize /proc/cmdline; then
    if ! grep -q splash /tmp/1/cmdline.txt; then
      sed -i "s| quiet||g" /tmp/1/cmdline.txt
    fi
    sed -i 's| init=/usr/lib/raspi-config/init_resize.sh||' /tmp/1/cmdline.txt
  else
    sed -i '1 s|.*|& sdhci.debug_quirks2=4|' /tmp/1/cmdline.txt
  fi







UMOUNTBOOTWSPINNER1noshow() {

count=0
while true
do
	if [ -e /boot/config.txt ]
	then
        	echz "### BOOT WAS NOT MOUNTED"
		sleep 5
	else
        	echz "### BOOT WAS NOT MOUNTED"
		sleep 5
        fi


    i=0
    marks='/ - \ |'
    if [ $# -lt 4 ]; then
      set -- "$@" $marks
    fi
    shift $(( (i+1) % $# ))
    
    printf 'Waiting for umount boot: %s\r' "$1"
    sleep 1


    count=$((count+1))

    if [[ ${count} -eq 15 ]]
    then
        echo "Timed out."; break
    fi
done


}









#[   46.385776] /boot/rpi-multi-init.sh: edit and sfdisk /dev/mmcblk0 < /tmp/table
#[   47.418634] /boot/rpi-multi-init.sh: /dev/mmcblk0 last part OK: /dev/mmcblk0p2 : start=      802816, size=     1966080, type=83
#[   48.431522] /boot/rpi-multi-init.sh: Writing two more part entries
#[   49.451471] /boot/rpi-multi-init.sh: sfdisk write: 0
#[   52.459671] /boot/rpi-multi-init.sh: mkfs.ext4 -L os1 /dev/mmcblk0p3 [test]
#[   53.735042] /boot/rpi-multi-init.sh: dbg-manualoff: mkfs.ext4 -L os1 /dev/mmcblk0p3
#[   55.010181] /boot/rpi-multi-init.sh: dbg-manualogg: mkfs.ext4 -L os2 /dev/mmcblk0p4
#[   56.019515] /boot/rpi-multi-init.sh: mkfs.ext4 -L os3 /dev/sdaX [not-implemented-please-do-manually
#[   57.030724] /boot/rpi-multi-init.sh: sync...
#[   58.045986] /boot/rpi-multi-init.sh: reboot > or back in script1 based on retval
#[   59.057498] /boot/rpi-multi-init.sh: remounting boot for cleanup
#[   60.079736] /dev/mmcblk0p1: Can't open blockdev
#[   60.087670] /boot/rpi-multi-init.sh: prob?: mount g
#










