#!/bin/sh







#!!!!!!!!!!!!!!!!!!!!!!!!!!! in ramfs @ /etc/custom/ramfs/ AND /boot multi.zip !!!!!!!!!!!!!!!!!!!!!!!!!!!






echz() {
    echo "ECHZ@FUNCMIGRATING> $ZW: ${*}" > /dev/kmsg
    sleep 1
}




##################################################### BELOW ALL IN multi-init now... only state detection / toggle here!!!!



fsckadisk() { #1 fstype #2 /dev/diskNUM

	#leaving echz test clearly later re: defined pre|post this sourced

	#command -v fsck.$1 || #check for fsck.fat etc.
	echz "fsck.$1@$2 [run]"

    case "$1" in

		fat) echz "$(fsck.fat -y $2)"; ;;
		#fsck.fat -y /dev/mmcblk0p1 #&& echz "retval:$?" #fsck.fat -n /dev/mmcblk0p1 &>/dev/null && echo $? > /dev/kmsg
        #fsck.vfat -l -v -a -t $1
        #-a $2
		ext4)
       	    fsck.ext4 -n $2 &>/dev/null; retval=$?
			if [ "$retval" -ne 0 ]; then
                echz "fsck@$2 [fsck-repair]"
				echz "$(fsck.ext4 -y $2 &>/dev/null)" #echz "retval: $?"
            else
                echz "fsck.$1 @$2 [fsck-clean]"
            fi
        ;;
        *)
            echz "$FN> unknown fs: $1"
        ;;
    esac

}
#echz "$(fsck.fat -y $2)"; echz "retval:$?" #!!! retvalNOTVALIDpreviousechz
#echz "fsck@$2 [init-report]"





cmdlinegetprop() { FN="cmdlinegetprop"

local cmdlinegetprop="${1}" #rootfs|ramopt|...

	if read cmdline < /proc/cmdline; then
        #######################################################################
		case "$cmdlinegetprop" in
			rootfs)
				case "$cmdline" in
					*root=*) cmdlineprop="${cmdline##*root=}"; cmdlineprop="${cmdlineprop%% *}"; ;;
				esac
			;;
			ramopt)
				case "$cmdline" in
                    *ramopt=*) cmdlineprop="${cmdline##*ramopt=}"; cmdlineprop="${cmdlineprop%% *}"; ;;
                esac
            ;;
		esac #endcase1cmdlinegetprop
        #######################################################################
		if [ ! -z "${cmdlineprop}" ]; then echo "${cmdlineprop}"; return 0; fi
	else
		echo "cmdline is not readable" >> /tmp/ISSUELOG #echU "cmdline is not readable"
        fails "$FN> commandline-notreadable"
    fi
	return 1
} #cmdlineprop-ZCANTECHO: #echo "cmdline@$cmdlinegetprop empty" ######echU "cmdline@$cmdlinegetprop empty"
#echo "$(cat /boot/cmdline.txt) os_prefix=$OSdir ramopt=partinit" > "$OSbase/$OSdir/cmdline.txt"
#echo "cmdlinegetprop-ramopt: $(cmdlinegetprop "ramopt")"

#part="$(awk -F 'ubi.mtd=' '{printf $2}' /proc/cmdline | sed -e 's/ .*$//')"








cmdlinetoramfsparams() {



	#NB: echi@10- echz@here? and altbootscripts...
	#dont think echz is working... >>> for now use echo kmsg

	local FN="cmdlinetoramfsparams"


	RAMOPTsD="ramfsinit.sh"
	#!!! NOTIFWEARE-NATIVE why was this set? lazy... testing shortcut? expecting later sed?/adjustonNATIVE?
        #ALSO WHY IS IT HERE FUNCTIONALISE cOMPRESSION... needs to be in ramfsinit.ini with -z ->FAILSAFE+warnhere

        #NOTE: likely ini not loaded yet... debug@pre/post main calls and shift this logic lower? ifposs

        #!!!!!!!!!!!!!!!!! FALSE ALARM... THAT IS THE CORRECT SCRIPT ... STILL NICE TO HAVE NATIVE MODIFYERparametc.


#echo "cmdlinetoramfsparams" > /dev/kmsg
#sleep 7



	RAMOPTs=$(cmdlinegetprop "ramopt")
    	



	echz "$FN> TEST cmdline ramopt: $RAMOPTs"
	echz "$FN> TEST cmdline ramoptsD: $RAMOPTsD"


	sleep 6



	if [ -z "$RAMOPTs" ]; then
    		RAMOPTs="${RAMOPTsD}"
    		echz "cmdline ramopt use-default"




    		#SUPPOSE 10-X wont BE SITTING in NATIVE /etc/uci-def NORMALLY ANYWAY...
    		#!!! accidentally left 10-testingmanually on liveNATIVEOS in uci-def...
    		#interestingly... it ran multi-init.sh???@FALSEALAREM<thatiscorrect

    		#@@@ DETECT WE ARE NATIVEHERE AND IMPLEMENTSOME HOOKS OR VERBOSEINFOORCLEANUPS(incase decide to implement->likely)...
    		#@also... trackdown the cause of multi-init.sh selection ff/? KEEP LOG!!! FALSEALARM



    		#echo "func-cmdlinetoramfsparams>" > /dev/kmsg; sleep 7
    		echi "IAM-ECHI-FROM-FUNC-FROM-10wECHI-func-cmdlinetoramfsparams>" 3 0
    		echo "IAM-ECHI(as echo to know)-FROM-FUNC-FROM-10wECHI-func-cmdlinetoramfsparams>" > /dev/kmsg
    		sleep 3


    if ! grep -q 'ramopt' /proc/cmdline; then
        #check config.txt ^os_prefix cnt etc. etc. etc. also
        echo "NATIVE-DEFAULT-FALLBACK" > /dev/kmsg

    else
        echo "NONNATIVE-DEFAULT-FALLBACK" > /dev/kmsg
    fi; sleep 5




else
    		echz "$FN> cmdline ramoptS RAMOPTs: ${RAMOPTs} WASNOTMEMPTY!!!"
fi






case "$RAMOPTs" in #CANDOALLHERE... > JUST SET VARS AND SETUP HANDLE MIGRATION || scriptnamechanges
    partinit)
        bootscript="/boot/rpi-multi-init.sh"
        SCRVOLATILE=1 #@end<-cleanup-ish ignores boot/.notoggle i.e. FORCES sed #os_prefix=os0...proballTOPVAR@revertXYZDEFACT??

        #20200910downfromtop10uciLAZYGLOBALDEFAULT now unset fall back may be overwritten by load$SCR.ini

		bsMETHOD="tmprun" #WASdefault HOW DID IT WORK WITHOUT THE COPY PHASE?

		####### well seeings as we might need a few parameters... prefer ini... needtoCHANGEdefault@topTO'D'thenassignonZ>cmd
		#WOULD passing a false full-path /tmp/NAMEviacmdlinethenset(Nscanfortherealpathoncopy/start)bsMETHOD from that be better?
		#orFROMini
		#orFROMcmdline 'tmprun' @ sed ^[^.*]ramopt=XYZ tmprun >>> grep -q tmprun /proc/cmdline || bsMETHOD="direct" etc...
	 ;;
    *)
        #@??? NATIVE OR NONNATIVE? !!! likely use same script ... but send alt param / ff /etc... possibly not here...
    	echz "$FN> DEFAULTCASEFALLBACK ramoptS RAMOPTs: bootscript=\${RAMOPTs}@${RAMOPTs}"
        bootscript="${RAMOPTs}";
        ;; #not adding /boot here to fix pass dummyboot.sh bsMETHOD alreadyhasfallback@top10uci
esac
#echz "bootscript: $bootscript [nameprint@endsin${ZBSCRIPT}]" #######bootscript="${ZBSCRIPT}"
#########bootscript="/boot/$(ls -1 /boot/ | grep "$ZBSCRIPT" | head -n1)"
#RAMOPTi=$(cmdlinegetprop "ramini")... @>>> . ZBSCRIPT! "takethese-thisrun-instead-of-params" style ini...
#aka 10-X(all?) if /boot/thisrun.ini load

#@@@ parse * for VERBOSE and print settings!!!
}








rclocalonceadd() { #||uci-defaultsnot
sed -i '$ d' /etc/rc.local
cat <<EOT >> /etc/rc.local
#SNEAKYTOP
opkg remove buggyprogram
sed -i '/#SNEAKYTOP/,/#SNEAKYBOTTOM/d' /etc/rc.local
#SNEAKYBOTTOM
exit 0
EOT
}
#sed -i -e "/^[^#]*$/d" /etc/rc.local








SAMPLESEDSTUFFatCONFIGBOOTOPTKEEPWASINLINE() {

echz "env os_prefix: $(echo $os_prefix)"

#cat /boot/config.txt | grep '^os_prefix='
ospfxnum=$(cat /boot/config.txt | grep '^os_prefix=' | wc -l)
ospfxlast=$(cat /boot/config.txt | grep '^os_prefix=' | tail -n1)
echz "config.txt os_prefix: $ospfxlast [current]"; sleep 2



if [ -f /boot/.prefixrestore ]; then
    echz "/boot/.prefixrestore [load]"
    echz "cat $(cat /boot/.prefixrestore)"
    . /boot/.prefixrestore

    echz "/boot/config.txt [comment out current $ospfxlast]"
    sed -i "s!^$ospfxlast!#$ospfxlast!g" /boot/config.txt
    echz "/boot/config.txt [commentout os_prefix check playback"
    echz "$(cat /boot/config.txt | grep 'os_prefix')"



    echz "/boot/config.txt [reset os_prefix:$os_prefix]"
    sed -i "s!^#os_prefix=$os_prefix!os_prefix=$os_prefix!g" /boot/config.txt

    echz "/boot/config.txt [reset os_prefix:$os_prefix] check playback"
    echz "$(cat /boot/config.txt | grep '^os_prefix')"

else


    echz "/boot/.prefixrestore [nope]"
    echz "probably just disable self line here $ospfxlast [nope]"
    echz "sed -i \"s!^$ospfxlast!#$ospfxlast!g\" /boot/config.txt"
    #sed -i "s!^$ospfxlast!#$ospfxlast!g" /boot/config.txt


    echz "############ YOUMUSTDOTHISMANUALLYNOW"
fi

}














printROOTDEVno() {
   if [ "$(command -v mountpoint | wc -l)" -gt 0 ]; then
        #echi "$(mountpoint -d /)"
        mptDEVno=$(mountpoint -d /)
	case "$mptDEVno" in
            *"0:2")
                echi "#############################################"
                echi "############     RAMFS:$mptDEVno        #########"
                echi "#############################################"
            ;;
            *)
                echi "#############################################"
                echi "############     ROOTDEV:$mptDEVno       ########"
                echi "#############################################"
            ;;

        esac

   else
	echi "no mountpoint command"
   fi



}









echo "ramfs.func.test.callerinfo:$(ps w | grep "$PPID" | grep -v grep)" > /dev/kmsg


if ! type echi >/dev/null 2>/dev/null; then
	echo "ramfs.func.sh creatingbackup echi"
	echo "ramfs.func.sh creatingbackup echi" > /dev/kmsg
	echi() { echo "ramfs.func.echi.backup> ${*}"; }
fi

#printROOTDEVno






