#!/bin/sh



#PLACEHOLDER FOR UNKNOWN RAMFS ACTION || bootlive etc.
#take a parameter||ini i.e. case bootlive etc... could / should be in 10-x etc but testing is too slow
#bootlive [peristent||@.ramfspersistent] specifybackup.tar.gzNAME||skip||none2load... otherwisecheck@last>@check-default@printnone
#backup multios's??? etc.


if [ -f /boot/ramfs.func.sh ]; then
	echo "load: . /boot/ramfs.func.sh" > /dev/kmsg
	. /boot/ramfs.func.sh
else
	echo "nofile: . /boot/ramfs.func.sh" > /dev/kmsg
	#echz "nofile: . /boot/ramfs.func.sh"
fi

#type or declare

if [ -f /boot/ramfsinit.ini ]; then
	echo "load: . /boot/ramfsinit.ini" > /dev/kmsg
	. /boot/ramfsinit.ini
else
	echo "nofile: . /boot/ramfsinit.ini" > /dev/kmsg
	#echz "nofile: . /boot/ramfsinit.ini"
fi





echo "$0 INIT DEFAULT OPERATIONS" > /dev/kmsg
#LOGTO-ramfsoperations-running-log?whatwherewhenhowwhysimilartoreplogs
sleep 3
#call config.txt togglerfunction-<mostparamsfrom-ini/s-multibootmostly






echz "I AM ECHZ from RAMFSINIT.SH SLEEP 3"; sleep 3


#fuckalltheseneedtoberc.dfirstbooted:_
#post-toggle check for sub-command-only script early



if [ ! -z "$ramfsconfigrestore" ]; then

	echo "$0 ini-ramfsconfigrestore: $ramfsconfigrestore" > /dev/kmsg
	sleep 2
	if [ -f "$ramfsconfigrestore" ]; then
	
		echo "$0 ini-ramfsconfigrestore: $ramfsconfigrestore LOAD" > /dev/kmsg
		sysupgrade -r $ramfsconfigrestore
		sleep 2
	else
		echo "$0 ini-ramfsconfigrestore: $ramfsconfigrestore NOFILE" > /dev/kmsg
		sleep 2
	fi
else
		echo "$0 ini-ramfsconfigrestore: $ramfsconfigrestore VAR-Z-OR-LOADFAIL" > /dev/kmsg
fi




#post-toggle check for sub-command-only script late





touch /tmp/bootscript.success
exit 0









