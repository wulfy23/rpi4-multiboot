#!/bin/sh



echz() {
    echo "ECHZ@FUNCMIGRATING> $ZW: ${*}" > /dev/kmsg
    sleep 1
}




##################################################### BELOW ALL IN multi-init now... only state detection / toggle here!!!!






fsckadisk() { #1 fstype #2 /dev/diskNUM

#leaving echz test clearly later re: defined pre|post this sourced


	#command -v fsck.$1 || #check for fsck.fat etc.
	echz "fsck.$1@$2 [run]"

    case "$1" in

		fat) echz "$(fsck.fat -y $2)"; ;;
		#fsck.fat -y /dev/mmcblk0p1 #&& echz "retval:$?" #fsck.fat -n /dev/mmcblk0p1 &>/dev/null && echo $? > /dev/kmsg

		ext4)
       	    fsck.ext4 -n $2 &>/dev/null; retval=$?
			if [ "$retval" -ne 0 ]; then
                echz "fsck@$2 [fsck-repair]"
				echz "$(fsck.ext4 -y $2 &>/dev/null)" #echz "retval: $?"
            else
                echz "fsck.$1 @$2 [fsck-clean]"
            fi
        ;;
        *)
            echz "$FN> unknown fs: $1"
        ;;
    esac

}
#echz "$(fsck.fat -y $2)"; echz "retval:$?" #!!! retvalNOTVALIDpreviousechz
#echz "fsck@$2 [init-report]"






cmdlinegetprop() { FN="cmdlinegetprop"

local cmdlinegetprop="${1}" #rootfs|ramopt|...

	if read cmdline < /proc/cmdline; then
        #######################################################################
		case "$cmdlinegetprop" in
			rootfs)
				case "$cmdline" in
					*root=*) cmdlineprop="${cmdline##*root=}"; cmdlineprop="${cmdlineprop%% *}"; ;;
				esac
			;;
			ramopt)
				case "$cmdline" in
                    *ramopt=*) cmdlineprop="${cmdline##*ramopt=}"; cmdlineprop="${cmdlineprop%% *}"; ;;
                esac
            ;;
		esac #endcase1cmdlinegetprop
        #######################################################################
		if [ ! -z "${cmdlineprop}" ]; then echo "${cmdlineprop}"; return 0; fi
	else
		echo "cmdline is not readable" >> /tmp/ISSUELOG #echU "cmdline is not readable"
        fails "$FN> commandline-notreadable"
    fi
	return 1
} #cmdlineprop-ZCANTECHO: #echo "cmdline@$cmdlinegetprop empty" ######echU "cmdline@$cmdlinegetprop empty"
#echo "$(cat /boot/cmdline.txt) os_prefix=$OSdir ramopt=partinit" > "$OSbase/$OSdir/cmdline.txt"
#echo "cmdlinegetprop-ramopt: $(cmdlinegetprop "ramopt")"






cmdlinetoramfsparams() {


RAMOPTsD="ramfsinit.sh"
RAMOPTs=$(cmdlinegetprop "ramopt")
if [ -z "$RAMOPTs" ]; then RAMOPTs="${RAMOPTsD}"; echz "cmdline ramopt use-default"; fi


case "$RAMOPTs" in #CANDOALLHERE... > JUST SET VARS AND SETUP HANDLE MIGRATION || scriptnamechanges
    partinit)
        bootscript="/boot/rpi-multi-init.sh"
        SCRVOLATILE=1 #@end<-cleanup-ish ignores boot/.notoggle i.e. FORCES sed #os_prefix=os0...proballTOPVAR@revertXYZDEFACT??

        #20200910downfromtop10uciLAZYGLOBALDEFAULT now unset fall back may be overwritten by load$SCR.ini

		bsMETHOD="tmprun" #WASdefault HOW DID IT WORK WITHOUT THE COPY PHASE?

		####### well seeings as we might need a few parameters... prefer ini... needtoCHANGEdefault@topTO'D'thenassignonZ>cmd
		#WOULD passing a false full-path /tmp/NAMEviacmdlinethenset(Nscanfortherealpathoncopy/start)bsMETHOD from that be better?
		#orFROMini
		#orFROMcmdline 'tmprun' @ sed ^[^.*]ramopt=XYZ tmprun >>> grep -q tmprun /proc/cmdline || bsMETHOD="direct" etc...

	 ;;
    *) bootscript="${RAMOPTs}"; ;; #not adding /boot here to fix pass dummyboot.sh bsMETHOD alreadyhasfallback@top10uci
esac
#echz "bootscript: $bootscript [nameprint@endsin${ZBSCRIPT}]" #######bootscript="${ZBSCRIPT}"
#########bootscript="/boot/$(ls -1 /boot/ | grep "$ZBSCRIPT" | head -n1)"
#RAMOPTi=$(cmdlinegetprop "ramini")... @>>> . ZBSCRIPT!



#@@@ parse * for VERBOSE and print settings!!!


}











rclocalonceadd() { #||uci-defaultsnot
sed -i '$ d' /etc/rc.local
cat <<EOT >> /etc/rc.local
#SNEAKYTOP
opkg remove buggyprogram
sed -i '/#SNEAKYTOP/,/#SNEAKYBOTTOM/d' /etc/rc.local
#SNEAKYBOTTOM
exit 0
EOT
}
#sed -i -e "/^[^#]*$/d" /etc/rc.local














SAMPLESEDSTUFFatCONFIGBOOTOPTKEEPWASINLINE() {

echz "env os_prefix: $(echo $os_prefix)"

#cat /boot/config.txt | grep '^os_prefix='
ospfxnum=$(cat /boot/config.txt | grep '^os_prefix=' | wc -l)
ospfxlast=$(cat /boot/config.txt | grep '^os_prefix=' | tail -n1)
echz "config.txt os_prefix: $ospfxlast [current]"; sleep 2



if [ -f /boot/.prefixrestore ]; then
    echz "/boot/.prefixrestore [load]"
    echz "cat $(cat /boot/.prefixrestore)"
    . /boot/.prefixrestore

    echz "/boot/config.txt [comment out current $ospfxlast]"
    sed -i "s!^$ospfxlast!#$ospfxlast!g" /boot/config.txt
    echz "/boot/config.txt [commentout os_prefix check playback"
    echz "$(cat /boot/config.txt | grep 'os_prefix')"



    echz "/boot/config.txt [reset os_prefix:$os_prefix]"
    sed -i "s!^#os_prefix=$os_prefix!os_prefix=$os_prefix!g" /boot/config.txt

    echz "/boot/config.txt [reset os_prefix:$os_prefix] check playback"
    echz "$(cat /boot/config.txt | grep '^os_prefix')"

else


    echz "/boot/.prefixrestore [nope]"
    echz "probably just disable self line here $ospfxlast [nope]"
    echz "sed -i \"s!^$ospfxlast!#$ospfxlast!g\" /boot/config.txt"
    #sed -i "s!^$ospfxlast!#$ospfxlast!g" /boot/config.txt


    echz "############ YOUMUSTDOTHISMANUALLYNOW"
fi

}









#root@OpenWrt:/# fsck.fat /dev/mmcblk0p1
#CP437: No error information
#fsck.fat 4.1 (2017-01-24)
#0x25: Dirty bit is set. Fs was not properly unmounted and some data may be corrupt.
#1) Remove dirty bit
#2) No action






#root@OpenWrt:/# sfdisk -d /dev/mmcblk0 > /tmp/tableGPTnew
#root@OpenWrt:/# cat /tmp/tableGPTnew
#label: gpt
#label-id: 28BE9558-8D3E-4095-9BD6-675E63509ADA
#device: /dev/mmcblk0
#unit: sectors
#first-lba: 34
#last-lba: 62521310
#sector-size: 512
#
#/dev/mmcblk0p1 : start=        8192, size=      786432, type=EBD0A0A2-B9E5-4433-87C0-68B6B72699C7, uuid=051AEDDB-BDE2-43B6-B054-9FBF4C"
#/dev/mmcblk0p2 : start=      802816, size=     1966080, type=0FC63DAF-8483-4772-8E79-3D69D8477DE4, uuid=D801B487-DFB9-474D-8DA1-065882"
#/dev/mmcblk0p3 : start=     2768896, size=     2097152, type=0FC63DAF-8483-4772-8E79-3D69D8477DE4, uuid=36960247-C6AB-407B-8BB0-C511B2"
#/dev/mmcblk0p4 : start=     4866048, size=     2097152, type=0FC63DAF-8483-4772-8E79-3D69D8477DE4, uuid=04535BE2-44ED-457E-9D20-F976B3"



##########################root@OpenWrt:/# cat /tmp/table
#label: dos
#label-id: 0x5452574f
#device: /dev/mmcblk0
#unit: sectors
#sector-size: 512
#
#/dev/mmcblk0p1 : start=        8192, size=      786432, type=c, bootable
#/dev/mmcblk0p2 : start=      802816, size=     1966080, type=83




#Device     Boot   Start     End Sectors  Size Id Type
#/dev/sdg1  *       8192  794623  786432  384M  c W95 FAT32 (LBA)
#/dev/sdg2        802816 2768895 1966080  960M 83 Linux
#/dev/sdg3       2768896 4866047 2097152    1G 83 Linux
#/dev/sdg4       4866048 6963199 2097152    1G 83 Linux






################# USED GDISK TO CREATE (butturnedintogpt) needed backup img... but cp sfdisk of new partinfo

################# debian did not like line 5 @ 512 had to remove to restore... not sure about openwrt




OLDERMAYBEfdiskpartcreatefailsthinksstartsectoris2048() {

#n
#p
#4
#
#+1G
#t
#83
#p
#w


#n
#p

fdisk /dev/mmcblk0 << __EOF__
n
p
3

+1G
t
83

w

__EOF__


fdisk /dev/mmcblk0 << __EOF__
n
p
4

+1G
t
83

w

__EOF__


}


















